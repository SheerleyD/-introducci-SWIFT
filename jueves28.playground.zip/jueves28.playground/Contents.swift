import UIKit

//Con las siguientes variables: let numero1 = 7 let numero2 = 11 Realiza tres operaciones aritmeticas y tres operaciones de comparación.
let numero1 = 7
let numero2 = 11

let multi = numero1 * numero2
let suma = numero1 + numero2
let modulo = numero2 % numero1

let igualdad = numero1 == numero2
let diferente = numero1 != numero2
let mayorIgual = numero1 >= numero2

//Declara un arreglo de enteros con mas de 5 elementos.
var enteros: [Int] = [3, 6, 9, 12, 15, 18]

//Encuentra el numero de elementos del arreglo.
let cantidadEnteros = enteros.count

//Imprime el arreglo ordenado utilizando el metodo sorted()
var enterosDesord = [9, 15, 18, 3, 6, 12]
let enterosOrd = enterosDesord.sorted

//Agrega dos elementos al arreglo
enteros.append(1)
enteros.append(5)

//Elimina el tercer elemento del arreglo
enteros.remove(at: 2)
print(enteros)
//Con las variables: let a = 4 let b = 3 Si 'a' es mas grande que 'b' imprime un mensaje que diga "A es mas grande que B" Utilizando If
let a = 4
let b = 3

if a > b {
    print ("A es mas grande que B")
}

//En una variable declara tu edad y utilizando el operador ternario determina si eres mayor de 21 o no impreso en pantalla
let edad = 22

let result = edad > 21 ? "Mayor que 21" : "Menor que 21"
print (result)

//Haz una estructura if, else if, else para cada variable siguiente donde se determine si un numero es positivo, negativo o es cero. let num1 = 3 let num2 = -4
let num1 = 3
if num1 > 0 {
    print ("El numero es positivo")
} else if num1 < 0 {
    print ("El numero es negativo")
} else {
    print ("El numero es cero")
}

let num2 = -4
if num2 > 0 {
    print ("El numero es positivo")
} else if num2 < 0 {
    print ("El numero es negativo")
} else {
    print ("El numero es cero")
}

//Declara la variable let clima = "Soleado" Y crea una estructura switch para para determinar si el clima es agradable con los casos: case "Soleado" -> Es agradable case "Nublado" -> No es agradable case "Lloviendo" -> No es agradable
let clima = "soleado"
switch clima {
case "soleado":
    print ("Es agradable")
case "nublado", "lloviendo":
    print ("No es agradable")
default:
    print ("Chin")
}

